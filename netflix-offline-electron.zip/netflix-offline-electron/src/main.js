const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

let mainWindow;

// ------------------------------------------------------------------
// A packaged .app launched from Finder/Dock does NOT inherit the
// PATH your shell builds from .zshrc/.bash_profile (Homebrew, Android
// SDK, etc). Extend PATH with the common install locations so adb/
// afconvert/ffmpeg are still found without requiring a Terminal launch.
// ------------------------------------------------------------------
function extendedPath() {
  const home = os.homedir();
  const extras = [
    '/opt/homebrew/bin',
    '/opt/homebrew/sbin',
    '/usr/local/bin',
    '/usr/local/sbin',
    path.join(home, 'Library/Android/sdk/platform-tools'),
    path.join(home, 'Android/Sdk/platform-tools'),
    '/usr/bin',
    '/bin',
    '/usr/sbin',
    '/sbin'
  ];
  const current = (process.env.PATH || '').split(':').filter(Boolean);
  const merged = [...new Set([...current, ...extras])];
  return merged.join(':');
}

const SPAWN_ENV = { ...process.env, PATH: extendedPath() };

const DEFAULTS = {
  deviceIp: '192.168.0.169',
  cachePath: '/sdcard/android/data/com.netflix.mediaclient/files/download/.of/',
  destRoot: path.join(os.homedir(), 'Netflix_sources')
};

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 980,
    height: 760,
    minWidth: 720,
    minHeight: 560,
    title: 'Netflix Offline Toolkit',
    backgroundColor: '#1c1b19',
    titleBarStyle: 'hiddenInset',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

// ------------------------------------------------------------------
// Generic command runner — streams stdout/stderr back to renderer
// as 'log' events, resolves with {code, stdout, stderr}
// ------------------------------------------------------------------
function run(cmd, args, { channel = 'log', cwd } = {}) {
  return new Promise((resolve) => {
    mainWindow.webContents.send(channel, { type: 'cmd', text: `$ ${cmd} ${args.join(' ')}` });

    const child = spawn(cmd, args, { cwd, env: SPAWN_ENV });
    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (data) => {
      const text = data.toString();
      stdout += text;
      mainWindow.webContents.send(channel, { type: 'stdout', text });
    });

    child.stderr.on('data', (data) => {
      const text = data.toString();
      stderr += text;
      mainWindow.webContents.send(channel, { type: 'stderr', text });
    });

    child.on('error', (err) => {
      mainWindow.webContents.send(channel, { type: 'error', text: `${err.message}` });
      resolve({ code: -1, stdout, stderr: stderr + err.message });
    });

    child.on('close', (code) => {
      resolve({ code, stdout, stderr });
    });
  });
}

function commandExists(cmd) {
  return new Promise((resolve) => {
    const which = spawn('which', [cmd], { env: SPAWN_ENV });
    let out = '';
    which.stdout.on('data', (d) => (out += d.toString()));
    which.on('close', (code) => resolve(code === 0 ? out.trim() : null));
  });
}

// ------------------------------------------------------------------
// IPC: environment checks
// ------------------------------------------------------------------
ipcMain.handle('check-tools', async () => {
  const [adb, afconvert, ffmpeg] = await Promise.all([
    commandExists('adb'),
    commandExists('afconvert'),
    commandExists('ffmpeg')
  ]);
  return {
    adb: { found: !!adb, path: adb },
    afconvert: { found: !!afconvert, path: afconvert },
    ffmpeg: { found: !!ffmpeg, path: ffmpeg },
    platform: process.platform
  };
});

ipcMain.handle('get-defaults', () => DEFAULTS);

// ------------------------------------------------------------------
// IPC: device status
// ------------------------------------------------------------------
ipcMain.handle('device-status', async () => {
  const result = await run('adb', ['devices', '-l'], { channel: 'silent-log' });
  if (result.code !== 0) {
    return { ok: false, devices: [], raw: result.stderr || 'adb not available' };
  }
  const lines = result.stdout
    .split('\n')
    .slice(1)
    .map((l) => l.trim())
    .filter(Boolean);

  const devices = lines.map((line) => {
    const parts = line.split(/\s+/);
    const serial = parts[0];
    const state = parts[1];
    const modelMatch = line.match(/model:(\S+)/);
    const model = modelMatch ? modelMatch[1].replace(/_/g, ' ') : null;
    return { serial, state, model };
  });

  return { ok: true, devices, raw: result.stdout };
});

ipcMain.handle('restart-adb', async () => {
  const kill = await run('adb', ['kill-server']);
  const start = await run('adb', ['start-server']);
  return { ok: kill.code === 0 && start.code === 0 };
});

// ------------------------------------------------------------------
// IPC: pairing / connecting over Wireless debugging
// ------------------------------------------------------------------
ipcMain.handle('adb-pair', async (_evt, { ip, port, code }) => {
  if (!ip || !port || !code) {
    return { ok: false, error: 'IP, pair port, and pairing code are all required.' };
  }
  const hostport = `${ip}:${port}`;
  const result = await run('adb', ['pair', hostport, code]);
  return { ok: result.code === 0, stdout: result.stdout, stderr: result.stderr };
});

ipcMain.handle('adb-connect', async (_evt, { ip, port }) => {
  if (!ip || !port) {
    return { ok: false, error: 'IP and connect port are required.' };
  }
  const hostport = `${ip}:${port}`;
  const result = await run('adb', ['connect', hostport]);
  return { ok: result.code === 0 && /connected/i.test(result.stdout), stdout: result.stdout, stderr: result.stderr };
});

// ------------------------------------------------------------------
// IPC: browse the Netflix offline cache path on the device
// ------------------------------------------------------------------
ipcMain.handle('list-remote-path', async (_evt, { cachePath }) => {
  const target = cachePath || DEFAULTS.cachePath;
  const result = await run('adb', ['shell', `ls -la '${target}'`]);
  if (result.code !== 0) {
    return { ok: false, error: result.stderr || 'Could not list that path.' };
  }

  // Parse `ls -la` output into folder/file entries, skipping . and ..
  const entries = result.stdout
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean)
    .filter((l) => !l.startsWith('total'))
    .map((line) => {
      const parts = line.split(/\s+/);
      const perms = parts[0] || '';
      const name = parts.slice(7).join(' ');
      return { name, isDir: perms.startsWith('d'), raw: line };
    })
    .filter((e) => e.name && e.name !== '.' && e.name !== '..');

  return { ok: true, entries, raw: result.stdout };
});

// ------------------------------------------------------------------
// IPC: pull a folder from the device
// ------------------------------------------------------------------
ipcMain.handle('pull-folder', async (_evt, { cachePath, folderName, destRoot }) => {
  const target = cachePath || DEFAULTS.cachePath;
  const root = destRoot || DEFAULTS.destRoot;
  const remotePath = `${target.replace(/\/$/, '')}/${folderName}`;
  const localDir = path.join(root, folderName);

  try {
    fs.mkdirSync(localDir, { recursive: true });
  } catch (e) {
    return { ok: false, error: `Could not create local folder: ${e.message}` };
  }

  const result = await run('adb', ['pull', remotePath, localDir]);
  if (result.code !== 0) {
    return { ok: false, error: result.stderr || 'adb pull failed.' };
  }

  // Find .nfa/.nfv files for the next step
  const found = [];
  const walk = (dir, depth) => {
    if (depth > 3) return;
    let items = [];
    try {
      items = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const item of items) {
      const full = path.join(dir, item.name);
      if (item.isDirectory()) walk(full, depth + 1);
      else if (/\.(nfa|nfv)$/i.test(item.name)) found.push(full);
    }
  };
  walk(localDir, 0);

  return { ok: true, localDir, remotePath, mediaFiles: found };
});

ipcMain.handle('reveal-in-finder', async (_evt, { targetPath }) => {
  if (process.platform === 'darwin' && fs.existsSync(targetPath)) {
    shell.showItemInFolder(targetPath);
    return { ok: true };
  }
  return { ok: false, error: 'Not on macOS or path does not exist.' };
});

ipcMain.handle('pick-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory', 'createDirectory']
  });
  if (result.canceled || result.filePaths.length === 0) return { ok: false };
  return { ok: true, path: result.filePaths[0] };
});

ipcMain.handle('pick-file', async (_evt, { filters } = {}) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: filters || []
  });
  if (result.canceled || result.filePaths.length === 0) return { ok: false };
  return { ok: true, path: result.filePaths[0] };
});

// ------------------------------------------------------------------
// IPC: find .nfa/.nfv files under an arbitrary local folder
// ------------------------------------------------------------------
ipcMain.handle('find-media-files', async (_evt, { dir }) => {
  if (!dir || !fs.existsSync(dir)) return { ok: false, error: 'Folder does not exist.' };
  const found = [];
  const walk = (d, depth) => {
    if (depth > 3) return;
    let items = [];
    try {
      items = fs.readdirSync(d, { withFileTypes: true });
    } catch {
      return;
    }
    for (const item of items) {
      const full = path.join(d, item.name);
      if (item.isDirectory()) walk(full, depth + 1);
      else if (/\.(nfa|nfv)$/i.test(item.name)) found.push(full);
    }
  };
  walk(dir, 0);
  return { ok: true, mediaFiles: found };
});

// ------------------------------------------------------------------
// IPC: convert .nfa -> .wav via afconvert (macOS only)
// ------------------------------------------------------------------
ipcMain.handle('convert-audio', async (_evt, { nfaFile, wavOut }) => {
  if (process.platform !== 'darwin') {
    return { ok: false, error: 'afconvert is macOS-only.' };
  }
  if (!nfaFile || !fs.existsSync(nfaFile)) {
    return { ok: false, error: 'Invalid .nfa file path.' };
  }
  const outPath = wavOut || nfaFile.replace(/\.[^.]+$/, '.wav');

  const result = await run('afconvert', ['-f', 'WAVE', '-d', 'LEI16', nfaFile, outPath]);
  if (result.code !== 0) {
    return { ok: false, error: result.stderr || 'afconvert failed.' };
  }
  return { ok: true, wavOut: outPath };
});

// ------------------------------------------------------------------
// IPC: mux audio + video with ffmpeg
// ------------------------------------------------------------------
ipcMain.handle('mux-video', async (_evt, { wavFile, mp4File, outFile }) => {
  if (!wavFile || !fs.existsSync(wavFile)) {
    return { ok: false, error: 'WAV file not found.' };
  }
  if (!mp4File || !fs.existsSync(mp4File)) {
    return { ok: false, error: 'MP4 file not found.' };
  }
  const outPath = outFile || mp4File.replace(/\.[^.]+$/, '_merged.mp4');

  const result = await run('ffmpeg', [
    '-y',
    '-i', mp4File,
    '-i', wavFile,
    '-map', '0:v',
    '-map', '1:a',
    '-c:v', 'copy',
    '-c:a', 'aac',
    outPath
  ]);

  if (result.code !== 0) {
    return { ok: false, error: result.stderr || 'ffmpeg mux failed.' };
  }
  return { ok: true, outFile: outPath };
});
