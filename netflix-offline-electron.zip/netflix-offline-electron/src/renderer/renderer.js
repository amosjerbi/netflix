// ============================================================
// State
// ============================================================
let currentStage = 1;
let lastPulledDir = null;
let lastWavFile = null;

// ============================================================
// Theme
// ============================================================
const THEME_KEY_FALLBACK = 'paper'; // no localStorage in this app on purpose; in-memory only
let currentTheme = THEME_KEY_FALLBACK;

function applyTheme(theme) {
  currentTheme = theme;
  document.body.setAttribute('data-theme', theme);
  const icon = document.getElementById('theme-icon');
  if (theme === 'dark') {
    icon.innerHTML = '<path d="M12 3v2M12 19v2M5 5l1.5 1.5M17.5 17.5L19 19M3 12h2M19 12h2M5 19l1.5-1.5M17.5 6.5L19 5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="12" cy="12" r="4.2" stroke="currentColor" stroke-width="1.6"/>';
  } else {
    icon.innerHTML = '<path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>';
  }
}

document.getElementById('theme-toggle').addEventListener('click', () => {
  applyTheme(currentTheme === 'paper' ? 'dark' : 'paper');
});

// ============================================================
// Log drawer
// ============================================================
const logDrawer = document.getElementById('log-drawer');
const logBody = document.getElementById('log-body');

document.getElementById('log-toggle').addEventListener('click', () => {
  const open = logDrawer.getAttribute('data-open') === 'true';
  logDrawer.setAttribute('data-open', open ? 'false' : 'true');
});

function appendLog({ type, text }) {
  const span = document.createElement('span');
  if (type === 'cmd') span.className = 'log-line-cmd';
  if (type === 'error' || type === 'stderr') span.className = 'log-line-error';
  span.textContent = text;
  logBody.appendChild(span);
  logBody.scrollTop = logBody.scrollHeight;
}

window.api.onLog((payload) => appendLog(payload));

// ============================================================
// Stage navigation
// ============================================================
function goToStage(n) {
  currentStage = n;
  document.querySelectorAll('.panel').forEach((p) => {
    p.setAttribute('data-active', p.id === `panel-${n}` ? 'true' : 'false');
  });
  document.querySelectorAll('.stage-node').forEach((node) => {
    const stage = parseInt(node.getAttribute('data-stage'), 10);
    if (stage === n) node.setAttribute('data-state', 'active');
    else if (stage < n) node.setAttribute('data-state', 'done');
    else node.removeAttribute('data-state');
  });
}

document.querySelectorAll('.stage-node').forEach((node) => {
  node.addEventListener('click', () => goToStage(parseInt(node.getAttribute('data-stage'), 10)));
});

document.getElementById('btn-skip-to-2').addEventListener('click', () => goToStage(2));
document.getElementById('btn-back-to-1').addEventListener('click', () => goToStage(1));
document.getElementById('btn-back-to-2').addEventListener('click', () => goToStage(2));
document.getElementById('btn-skip-mux').addEventListener('click', () => goToStage(5));
document.getElementById('btn-back-to-3').addEventListener('click', () => goToStage(3));
document.getElementById('btn-to-5').addEventListener('click', () => goToStage(5));
document.getElementById('btn-back-to-4').addEventListener('click', () => goToStage(4));

// ============================================================
// Init: defaults + tool checks + device status
// ============================================================
async function init() {
  const defaults = await window.api.getDefaults();
  document.getElementById('ip-input').value = defaults.deviceIp;
  document.getElementById('cache-path-input').value = defaults.cachePath;
  document.getElementById('dest-root-input').value = defaults.destRoot;

  await renderToolChecks();
  await refreshDeviceStatus();
  goToStage(1);
}

async function renderToolChecks() {
  const tools = await window.api.checkTools();
  const container = document.getElementById('tool-checks');
  container.innerHTML = '';

  const entries = [
    { key: 'adb', label: 'adb' },
    { key: 'afconvert', label: 'afconvert' },
    { key: 'ffmpeg', label: 'ffmpeg' }
  ];

  entries.forEach(({ key, label }) => {
    const info = tools[key];
    const chip = document.createElement('div');
    chip.className = 'tool-chip';
    chip.setAttribute('data-found', info.found ? 'true' : 'false');
    chip.innerHTML = `<span class="dot"></span><span>${label}</span>`;
    chip.title = info.found ? info.path : `${label} not found in PATH`;
    container.appendChild(chip);
  });

  if (tools.platform !== 'darwin') {
    const chip = document.createElement('div');
    chip.className = 'tool-chip';
    chip.setAttribute('data-found', 'false');
    chip.innerHTML = '<span class="dot"></span><span>non-macOS — afconvert unavailable</span>';
    container.appendChild(chip);
  }
}

async function refreshDeviceStatus() {
  const pill = document.getElementById('device-pill');
  const label = document.getElementById('device-label');
  const status = await window.api.deviceStatus();

  if (!status.ok) {
    pill.setAttribute('data-state', 'error');
    label.textContent = 'adb unavailable';
    return;
  }

  const connected = status.devices.find((d) => d.state === 'device');
  const unauthorized = status.devices.find((d) => d.state === 'unauthorized');

  if (connected) {
    pill.setAttribute('data-state', 'connected');
    label.textContent = connected.model ? `${connected.model} (${connected.serial})` : connected.serial;
  } else if (unauthorized) {
    pill.setAttribute('data-state', 'error');
    label.textContent = `Unauthorized — ${unauthorized.serial}`;
  } else {
    pill.removeAttribute('data-state');
    label.textContent = 'No device connected';
  }
}

document.getElementById('btn-refresh-status').addEventListener('click', refreshDeviceStatus);

// ============================================================
// Stage 1: connect
// ============================================================
document.getElementById('btn-restart-adb').addEventListener('click', async (e) => {
  const btn = e.currentTarget;
  btn.disabled = true;
  logDrawer.setAttribute('data-open', 'true');
  await window.api.restartAdb();
  btn.disabled = false;
  await refreshDeviceStatus();
});

document.getElementById('btn-pair').addEventListener('click', async (e) => {
  const btn = e.currentTarget;
  const ip = document.getElementById('ip-input').value.trim();
  const port = document.getElementById('pair-port-input').value.trim();
  const code = document.getElementById('pair-code-input').value.trim();

  btn.disabled = true;
  logDrawer.setAttribute('data-open', 'true');
  const result = await window.api.adbPair({ ip, port, code });
  btn.disabled = false;

  if (!result.ok) {
    appendLog({ type: 'error', text: `Pairing failed: ${result.error || result.stderr || 'unknown error'}\n` });
  }
});

document.getElementById('btn-connect').addEventListener('click', async (e) => {
  const btn = e.currentTarget;
  const ip = document.getElementById('ip-input').value.trim();
  const port = document.getElementById('connect-port-input').value.trim();

  btn.disabled = true;
  logDrawer.setAttribute('data-open', 'true');
  const result = await window.api.adbConnect({ ip, port });
  btn.disabled = false;

  await refreshDeviceStatus();
  if (result.ok) {
    document.getElementById('cache-path-input').focus();
  } else {
    appendLog({ type: 'error', text: `Connect failed: ${result.error || result.stderr || 'unknown error'}\n` });
  }
});

// ============================================================
// Stage 2: browse cache
// ============================================================
document.getElementById('btn-list-cache').addEventListener('click', async (e) => {
  const btn = e.currentTarget;
  const cachePath = document.getElementById('cache-path-input').value.trim();
  const listing = document.getElementById('cache-listing');

  btn.disabled = true;
  logDrawer.setAttribute('data-open', 'true');
  listing.innerHTML = '<p class="empty-hint">Listing&hellip;</p>';

  const result = await window.api.listRemotePath({ cachePath });
  btn.disabled = false;

  if (!result.ok) {
    listing.innerHTML = `<p class="empty-hint">${result.error}</p>`;
    return;
  }

  if (result.entries.length === 0) {
    listing.innerHTML = '<p class="empty-hint">Folder is empty.</p>';
    return;
  }

  listing.innerHTML = '';
  result.entries.forEach((entry) => {
    const row = document.createElement('div');
    row.className = 'listing-row';
    row.setAttribute('data-dir', entry.isDir ? 'true' : 'false');
    row.innerHTML = `<span class="badge">${entry.isDir ? 'DIR' : 'FILE'}</span><span>${entry.name}</span>`;
    row.addEventListener('click', () => {
      document.getElementById('folder-name-input').value = entry.name;
      goToStage(3);
    });
    listing.appendChild(row);
  });
});

// ============================================================
// Stage 3: pull
// ============================================================
document.getElementById('btn-choose-dest').addEventListener('click', async () => {
  const result = await window.api.pickFolder();
  if (result.ok) document.getElementById('dest-root-input').value = result.path;
});

document.getElementById('btn-pull').addEventListener('click', async (e) => {
  const btn = e.currentTarget;
  const cachePath = document.getElementById('cache-path-input').value.trim();
  const folderName = document.getElementById('folder-name-input').value.trim();
  const destRoot = document.getElementById('dest-root-input').value.trim();
  const resultDiv = document.getElementById('pull-result');

  if (!folderName) {
    resultDiv.innerHTML = '<div class="result-card"><span class="status-error">Enter a folder name first.</span></div>';
    return;
  }

  btn.disabled = true;
  logDrawer.setAttribute('data-open', 'true');
  resultDiv.innerHTML = '<div class="result-card">Pulling&hellip;</div>';

  const result = await window.api.pullFolder({ cachePath, folderName, destRoot });
  btn.disabled = false;

  if (!result.ok) {
    resultDiv.innerHTML = `<div class="result-card"><span class="status-error">Pull failed</span><span class="path">${result.error}</span></div>`;
    return;
  }

  lastPulledDir = result.localDir;

  let mediaHtml = '';
  if (result.mediaFiles.length > 0) {
    mediaHtml = result.mediaFiles
      .map((f) => `<div class="media-file-row" data-path="${f}">${f}</div>`)
      .join('');
  } else {
    mediaHtml = '<p class="empty-hint" style="padding:10px 0 0;">No .nfa/.nfv files found in the pulled folder.</p>';
  }

  resultDiv.innerHTML = `
    <div class="result-card">
      <span class="status-ok">Pulled successfully</span>
      <span class="path">${result.localDir}</span>
      ${mediaHtml}
    </div>
  `;

  resultDiv.querySelectorAll('.media-file-row').forEach((row) => {
    row.addEventListener('click', () => {
      document.getElementById('nfa-input').value = row.getAttribute('data-path');
      goToStage(4);
    });
  });

  await window.api.revealInFinder({ targetPath: result.localDir });
});

// ============================================================
// Stage 4: convert audio
// ============================================================
document.getElementById('btn-choose-nfa').addEventListener('click', async () => {
  const result = await window.api.pickFile({ filters: [{ name: 'Netflix audio', extensions: ['nfa'] }] });
  if (result.ok) document.getElementById('nfa-input').value = result.path;
});

document.getElementById('btn-convert').addEventListener('click', async (e) => {
  const btn = e.currentTarget;
  const nfaFile = document.getElementById('nfa-input').value.trim();
  const wavOut = document.getElementById('wav-out-input').value.trim();
  const resultDiv = document.getElementById('convert-result');

  if (!nfaFile) {
    resultDiv.innerHTML = '<div class="result-card"><span class="status-error">Choose a .nfa file first.</span></div>';
    return;
  }

  btn.disabled = true;
  logDrawer.setAttribute('data-open', 'true');
  resultDiv.innerHTML = '<div class="result-card">Converting&hellip;</div>';

  const result = await window.api.convertAudio({ nfaFile, wavOut: wavOut || undefined });
  btn.disabled = false;

  if (!result.ok) {
    resultDiv.innerHTML = `<div class="result-card"><span class="status-error">Conversion failed</span><span class="path">${result.error}</span></div>`;
    return;
  }

  lastWavFile = result.wavOut;
  resultDiv.innerHTML = `<div class="result-card"><span class="status-ok">Converted</span><span class="path">${result.wavOut}</span></div>`;
  document.getElementById('wav-input').value = result.wavOut;
});

// ============================================================
// Stage 5: merge
// ============================================================
document.getElementById('btn-choose-wav').addEventListener('click', async () => {
  const result = await window.api.pickFile({ filters: [{ name: 'WAV audio', extensions: ['wav'] }] });
  if (result.ok) document.getElementById('wav-input').value = result.path;
});

document.getElementById('btn-choose-mp4').addEventListener('click', async () => {
  const result = await window.api.pickFile({ filters: [{ name: 'MP4 video', extensions: ['mp4'] }] });
  if (result.ok) document.getElementById('mp4-input').value = result.path;
});

document.getElementById('btn-mux').addEventListener('click', async (e) => {
  const btn = e.currentTarget;
  const wavFile = document.getElementById('wav-input').value.trim() || lastWavFile;
  const mp4File = document.getElementById('mp4-input').value.trim();
  const outFile = document.getElementById('mp4-out-input').value.trim();
  const resultDiv = document.getElementById('mux-result');

  if (!wavFile || !mp4File) {
    resultDiv.innerHTML = '<div class="result-card"><span class="status-error">Both a .wav and a source .mp4 are required.</span></div>';
    return;
  }

  btn.disabled = true;
  logDrawer.setAttribute('data-open', 'true');
  resultDiv.innerHTML = '<div class="result-card">Merging&hellip;</div>';

  const result = await window.api.muxVideo({ wavFile, mp4File, outFile: outFile || undefined });
  btn.disabled = false;

  if (!result.ok) {
    resultDiv.innerHTML = `<div class="result-card"><span class="status-error">Merge failed</span><span class="path">${result.error}</span></div>`;
    return;
  }

  resultDiv.innerHTML = `<div class="result-card"><span class="status-ok">Done</span><span class="path">${result.outFile}</span></div>`;
  await window.api.revealInFinder({ targetPath: result.outFile });
});

// ============================================================
init();
