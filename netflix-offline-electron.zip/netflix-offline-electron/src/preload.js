const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  checkTools: () => ipcRenderer.invoke('check-tools'),
  getDefaults: () => ipcRenderer.invoke('get-defaults'),

  deviceStatus: () => ipcRenderer.invoke('device-status'),
  restartAdb: () => ipcRenderer.invoke('restart-adb'),

  adbPair: (args) => ipcRenderer.invoke('adb-pair', args),
  adbConnect: (args) => ipcRenderer.invoke('adb-connect', args),

  listRemotePath: (args) => ipcRenderer.invoke('list-remote-path', args),
  pullFolder: (args) => ipcRenderer.invoke('pull-folder', args),
  revealInFinder: (args) => ipcRenderer.invoke('reveal-in-finder', args),

  pickFolder: () => ipcRenderer.invoke('pick-folder'),
  pickFile: (args) => ipcRenderer.invoke('pick-file', args),
  findMediaFiles: (args) => ipcRenderer.invoke('find-media-files', args),

  convertAudio: (args) => ipcRenderer.invoke('convert-audio', args),
  muxVideo: (args) => ipcRenderer.invoke('mux-video', args),

  onLog: (callback) => {
    const listener = (_evt, payload) => callback(payload);
    ipcRenderer.on('log', listener);
    return () => ipcRenderer.removeListener('log', listener);
  }
});
